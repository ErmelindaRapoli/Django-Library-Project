#!c:\users\ermelinda.rapoli\work\corsi\python\09_django_lv_2\library_env\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
